import{j as o,o as r,f as t}from"./index-B3a7Jb0H.js";const a={__name:"index",setup(n){return(_,c)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
