import{j as o,o as r,f as t}from"./index-BFsvZ6df.js";const a={__name:"index",setup(n){return(_,c)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
