import{s as o,o as r,f as t}from"./index-DFov8sUH.js";const a={__name:"index",setup(n){return(s,_)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
