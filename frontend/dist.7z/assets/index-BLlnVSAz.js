import{j as o,o as r,f as t}from"./index-zNTDh2Kw.js";const a={__name:"index",setup(n){return(_,c)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
