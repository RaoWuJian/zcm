import{j as o,o as r,f as t}from"./index-zHe7z0Uw.js";const a={__name:"index",setup(n){return(_,c)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
