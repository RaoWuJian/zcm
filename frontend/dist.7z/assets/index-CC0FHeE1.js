import{s as o,o as r,f as t}from"./index-DD5tw4c2.js";const a={__name:"index",setup(n){return(s,_)=>{const e=t("router-view");return r(),o(e)}}};export{a as default};
